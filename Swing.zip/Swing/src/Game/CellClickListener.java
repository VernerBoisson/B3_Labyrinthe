package Game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class CellClickListener extends MouseAdapter {
    public void mouseClicked(MouseEvent e) {
        JLabel l = new JLabel();
        JTable target = (JTable)e.getSource();
        target.setBackground(Color.red);



        // How to getCell object here and change its background color to clicked cell
    }

}
