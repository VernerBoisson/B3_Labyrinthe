package Game;

import javax.swing.*;
import javax.swing.plaf.nimbus.NimbusLookAndFeel;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LevelEditor extends JFrame implements ActionListener {
    public LevelEditor() {
        super("Level Editor");
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setSize( 1000, 1000);
        this.setLocationRelativeTo(null);

        JPanel CP = (JPanel) this.getContentPane();
        CP.setLayout(new FlowLayout());
        JTable table = new JTable(30, 30);
        table.setBackground(Color.gray);
        table.addMouseListener(new CellClickListener());
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        int width = 10;
        for (int i = 0; i < 30; i++) {
            TableColumn col = table.getColumnModel().getColumn(i);
            col.setPreferredWidth(width);

        }
        table.setRowSelectionAllowed(false);
        CP.add (table);
        CP.add( new JButton("Save Labyrinthe"));
        CP.add( new JButton("Add Wall"));
        CP.add( new JButton("Add trap"));


    }

    public void changecolor() {

    }




    public static void main(String[] args) throws Exception {

    UIManager.setLookAndFeel( new NimbusLookAndFeel() );
    LevelEditor levelEditor = new LevelEditor();
    levelEditor.setVisible( true );
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
